import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import { AppData, Entry } from '../types';

const STORAGE_KEY = 'corpo-em-progresso-v1';
const PHOTO_DIR = `${FileSystem.documentDirectory}photos/`;

export const initialData: AppData = {
  activeProfile: 'voce',
  profiles: {
    voce: { key: 'voce', nome: 'Você' },
    esposa: { key: 'esposa', nome: 'Esposa' },
  },
  entries: {
    voce: [],
    esposa: [],
  },
};

export const ensurePhotoDir = async () => {
  const info = await FileSystem.getInfoAsync(PHOTO_DIR);
  if (!info.exists) await FileSystem.makeDirectoryAsync(PHOTO_DIR, { intermediates: true });
  return PHOTO_DIR;
};

export const copyPhotoToApp = async (sourceUri: string) => {
  await ensurePhotoDir();
  const ext = sourceUri.split('.').pop()?.split('?')[0] || 'jpg';
  const destination = `${PHOTO_DIR}${Date.now()}.${ext}`;
  await FileSystem.copyAsync({ from: sourceUri, to: destination });
  return destination;
};

export const loadAppData = async (): Promise<AppData> => {
  const raw = await AsyncStorage.getItem(STORAGE_KEY);
  if (!raw) return initialData;
  try {
    const parsed = JSON.parse(raw) as AppData;
    return {
      activeProfile: parsed.activeProfile || 'voce',
      profiles: parsed.profiles || initialData.profiles,
      entries: parsed.entries || initialData.entries,
    };
  } catch {
    return initialData;
  }
};

export const saveAppData = async (data: AppData) => {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

export const exportBackupJson = async (data: AppData) => {
  const fileUri = `${FileSystem.cacheDirectory}corpo-em-progresso-backup.json`;
  await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(data, null, 2));
  return fileUri;
};

export const importBackupJson = async (jsonText: string): Promise<AppData> => {
  const parsed = JSON.parse(jsonText) as AppData;
  return {
    activeProfile: parsed.activeProfile || 'voce',
    profiles: parsed.profiles || initialData.profiles,
    entries: parsed.entries || initialData.entries,
  };
};

export const removeEntryPhoto = async (entry?: Entry) => {
  if (!entry?.photoUri) return;
  try {
    await FileSystem.deleteAsync(entry.photoUri, { idempotent: true });
  } catch {}
};
